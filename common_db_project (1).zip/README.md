# common-db Module

Dynamic multi-country MariaDB DataSource provider with:
- Spring Boot configuration binding
- HikariCP pooling
- Flyway migrations (common + optional country-specific)
- MyBatis integration
- Health check mapper
- Exception hierarchy
- Testcontainers integration test

## Build & Install Locally
```bash
mvn clean install
```

## Example Usage (from dependent project)

Add dependency in `loading` or `report` module:
```xml
<dependency>
  <groupId>com.acme</groupId>
  <artifactId>common-db</artifactId>
  <version>1.0.0-SNAPSHOT</version>
</dependency>
```

Provide configuration (application.yml):
```yaml
app:
  countries:
    IN:
      displayName: India
      db:
        primary:
          host: localhost
          port: 3306
          database: core_in
          username: in_user
          password: secret
        pool:
          maxPoolSize: 10
          minimumIdle: 2
    US:
      displayName: United States
      db:
        primary:
          host: localhost
          port: 3307
          database: core_us
          username: us_user
          password: secret
```

Then in your job module obtain DataSource or let MyBatis autowire mappers.

## Demo Main
Run health check:
```bash
java -cp target/common-db-1.0.0-SNAPSHOT.jar \
     com.acme.commondb.demo.CommonDbDemoMain --job.country=IN
```

(Ensure a reachable database and configuration provided via properties or yaml.)

## Tests
Uses Testcontainers for integration test of Flyway + provider.

## Extending
- Add replica endpoint to `DbGroup` for read-only routing.
- Add metrics via Micrometer if needed.

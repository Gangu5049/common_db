CREATE TABLE IF NOT EXISTS orders (
  id VARCHAR(64) PRIMARY KEY,
  cust_id VARCHAR(32) NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  status CHAR(1) NOT NULL,
  created_at TIMESTAMP NOT NULL
);

DELIMITER $$
DROP PROCEDURE IF EXISTS sp_generate_report $$
CREATE PROCEDURE sp_generate_report(IN run_date DATE)
BEGIN
  SELECT id as orderId, amount, status, created_at as createdAt
  FROM orders
  WHERE DATE(created_at) = run_date;
END $$
DELIMITER ;

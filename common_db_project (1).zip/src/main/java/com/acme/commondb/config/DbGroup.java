package com.acme.commondb.config;

public class DbGroup {
    private Endpoint primary;
    private PoolConfig pool;

    public Endpoint getPrimary() {
        return primary;
    }

    public void setPrimary(Endpoint primary) {
        this.primary = primary;
    }

    public PoolConfig getPool() {
        return pool;
    }

    public void setPool(PoolConfig pool) {
        this.pool = pool;
    }
}

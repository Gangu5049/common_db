package com.acme.commondb.config;

import com.acme.commondb.datasource.DynamicDataSourceProvider;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

@Configuration
public class MyBatisCountryConfig {

    @Bean
    public SqlSessionFactory sqlSessionFactory(@Value("${job.country:IN}") String country,
                                               DynamicDataSourceProvider dsp) throws Exception {
        var ds = dsp.getPrimary(country);
        var factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(ds);
        var cfg = new org.apache.ibatis.session.Configuration();
        cfg.setMapUnderscoreToCamelCase(true);
        cfg.setDefaultStatementTimeout(60);
        factoryBean.setConfiguration(cfg);
        factoryBean.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources("classpath*:mappers/**/*.xml"));
        return factoryBean.getObject();
    }

    @Bean
    public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory f) {
        return new SqlSessionTemplate(f);
    }
}

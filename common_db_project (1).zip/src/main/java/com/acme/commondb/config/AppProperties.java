package com.acme.commondb.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import java.util.HashMap;
import java.util.Map;

@ConfigurationProperties(prefix = "app")
public class AppProperties {
    private Map<String, CountryConfig> countries = new HashMap<>();

    public Map<String, CountryConfig> getCountries() {
        return countries;
    }

    public void setCountries(Map<String, CountryConfig> countries) {
        this.countries = countries;
    }

    public void assertNotEmpty() {
        if (countries.isEmpty()) {
            throw new IllegalStateException("No countries configured under app.countries");
        }
    }
}

package com.acme.commondb.config;

public class CountryConfig {
    private DbGroup db;
    private String displayName;

    public DbGroup getDb() {
        return db;
    }

    public void setDb(DbGroup db) {
        this.db = db;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
}

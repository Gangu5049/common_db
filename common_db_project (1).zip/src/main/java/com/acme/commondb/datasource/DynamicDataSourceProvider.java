package com.acme.commondb.datasource;

import com.acme.commondb.config.*;
import com.acme.commondb.exception.MigrationException;
import com.acme.commondb.exception.UnknownCountryException;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.flywaydb.core.Flyway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PreDestroy;
import javax.sql.DataSource;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class DynamicDataSourceProvider {

    private static final Logger log = LoggerFactory.getLogger(DynamicDataSourceProvider.class);

    private final AppProperties props;
    private final ConcurrentMap<String, HikariDataSource> cache = new ConcurrentHashMap<>();

    public DynamicDataSourceProvider(AppProperties props) {
        this.props = props;
    }

    public DataSource getPrimary(String country) {
        return cache.computeIfAbsent(country, this::create);
    }

    private HikariDataSource create(String country) {
        CountryConfig cc = props.getCountries().get(country);
        if (cc == null) throw new UnknownCountryException(country);
        Endpoint ep = cc.getDb().getPrimary();
        PoolConfig pc = Optional.ofNullable(cc.getDb().getPool()).orElse(new PoolConfig());

        HikariConfig hc = new HikariConfig();
        hc.setJdbcUrl(ep.jdbcUrl());
        hc.setUsername(ep.getUsername());
        hc.setPassword(ep.getPassword());
        hc.setMaximumPoolSize(pc.getMaxPoolSize() != null ? pc.getMaxPoolSize() : 10);
        hc.setMinimumIdle(pc.getMinimumIdle() != null ? pc.getMinimumIdle() : 2);
        hc.setConnectionTimeout(pc.getConnectionTimeoutMs() != null ? pc.getConnectionTimeoutMs() : 30_000);
        if (pc.getLeakDetectionThresholdMs() != null) {
            hc.setLeakDetectionThreshold(pc.getLeakDetectionThresholdMs());
        }
        hc.setPoolName("HIKARI-" + country);

        HikariDataSource ds = new HikariDataSource(hc);
        migrate(ds, country);
        log.info("{{"event":"POOL_CREATED","country":"{}","url":"{}"}}", country, ep.jdbcUrl());
        return ds;
    }

    private void migrate(DataSource ds, String country) {
        try {
            Flyway flyway = Flyway.configure()
                    .dataSource(ds)
                    .locations("classpath:db/migration/common", "classpath:db/migration/" + country)
                    .ignoreMissingLocations(true)
                    .baselineOnMigrate(true)
                    .load();
            flyway.migrate();
        } catch (Exception ex) {
            throw new MigrationException(country, ex);
        }
    }

    @PreDestroy
    public void closeAll() {
        cache.values().forEach(HikariDataSource::close);
        log.info("{"event":"POOLS_CLOSED","count":{}}", cache.size());
    }
}

package com.acme.commondb.exception;

public class UnknownCountryException extends CommonDbException {
    public UnknownCountryException(String c) {
        super("Unknown country: " + c);
    }
}

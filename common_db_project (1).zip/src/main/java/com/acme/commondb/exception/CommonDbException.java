package com.acme.commondb.exception;

public class CommonDbException extends RuntimeException {
    public CommonDbException(String message) {
        super(message);
    }
    public CommonDbException(String message, Throwable cause) {
        super(message, cause);
    }
}

package com.acme.commondb.exception;

public class MigrationException extends CommonDbException {
    public MigrationException(String country, Throwable cause) {
        super("Migration failed for country=" + country, cause);
    }
}

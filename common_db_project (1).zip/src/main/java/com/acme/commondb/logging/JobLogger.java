package com.acme.commondb.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

public final class JobLogger {
    private static final Logger log = LoggerFactory.getLogger("JOB");

    private JobLogger(){}

    public static void logResult(String jobId, String country, Instant start, boolean success, String message, int metric){
        long dur = ChronoUnit.MILLIS.between(start, Instant.now());
        log.info("{{"jobId":"{}","country":"{}","durationMs":{},"success":{},"metric":{},"message":"{}"}}",
                jobId, country, dur, success, metric, escape(message));
    }

    private static String escape(String s){
        return s == null ? "" : s.replace(""","'");
    }
}

package com.acme.commondb.mapper.common;

public interface HealthCheckMapper {
    int ping();
}

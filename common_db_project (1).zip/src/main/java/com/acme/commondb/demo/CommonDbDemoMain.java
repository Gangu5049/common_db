package com.acme.commondb.demo;

import com.acme.commondb.config.ConfigBindingConfig;
import com.acme.commondb.config.MyBatisCountryConfig;
import com.acme.commondb.config.AppProperties;
import com.acme.commondb.datasource.DynamicDataSourceProvider;
import com.acme.commondb.mapper.common.HealthCheckMapper;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.*;

@Configuration
@ComponentScan(basePackages = "com.acme.commondb")
@MapperScan("com.acme.commondb.mapper.common")
@Import({ConfigBindingConfig.class, MyBatisCountryConfig.class})
public class CommonDbDemoMain {

    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = new SpringApplicationBuilder(CommonDbDemoMain.class)
                .web(WebApplicationType.NONE)
                .run(args);

        String country = ctx.getEnvironment().getProperty("job.country", "IN");
        HealthCheckMapper mapper = ctx.getBean(HealthCheckMapper.class);
        int result = mapper.ping();
        System.out.println("HealthCheck ping=" + result + " country=" + country);

        DynamicDataSourceProvider provider = ctx.getBean(DynamicDataSourceProvider.class);
        provider.getPrimary(country);

        ctx.close();
    }

    @Bean
    public DynamicDataSourceProvider dynamicDataSourceProvider(AppProperties props){
        return new DynamicDataSourceProvider(props);
    }
}
